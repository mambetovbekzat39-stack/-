# 🌿 АгроКарта KG — ИИ‑мониторинг полей

Веб-приложение для мониторинга полей Кыргызстана с использованием реальных спутниковых данных.

## ✨ Что нового в v2.0

- 📡 **Реальные данные NASA POWER** — климатические данные с реального API NASA
- 🗺 **Поиск любого города/села** Кыргызстана и СНГ через Nominatim OpenStreetMap
- 🛰 **Переключатель слоёв** — спутник Esri / стандартная карта
- 📱 **Полностью адаптивный дизайн** — телефон, планшет, ПК
- 🎨 **Тёмная тема** — комфортная работа на улице
- ⚡ **Быстрая загрузка** — нет лишних зависимостей
- 📊 **График с прогнозом** — NDVI за период + прогноз на 7 дней

## 🚀 Деплой на Render

1. Загрузите папку проекта на GitHub
2. Зайдите на [render.com](https://render.com) → New → Web Service
3. Выберите репозиторий
4. Render автоматически обнаружит `render.yaml`
5. Нажмите **Deploy**

**Или вручную:**
- Root Directory: `backend`
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn app:app --workers 2 --timeout 120 --bind 0.0.0.0:$PORT`

## 📁 Структура

```
agro-project/
├── backend/
│   ├── app.py          # Flask API
│   └── requirements.txt
├── frontend/
│   └── index.html      # Всё в одном файле
├── Procfile
├── render.yaml
└── README.md
```

## 🔌 API

### POST /api/analyze
```json
{
  "polygon": [[lon, lat], ...],
  "crop": "пшеница",
  "period": 30
}
```

Ответ:
- `health_grid` — GeoJSON сетка NDVI
- `stress_zones` — зоны стресса
- `time_series` — исторический ряд
- `forecast` — прогноз 7 дней
- `recommendation` — текст рекомендации
- `data_source` — источник данных (NASA POWER / модель)

## 🛰 Источники данных

| Источник | Описание |
|---|---|
| NASA POWER | Реальные ежедневные климатические данные (осадки, температура, солнечная радиация) |
| Nominatim | Поиск населённых пунктов OpenStreetMap |
| Esri World Imagery | Спутниковые тайлы высокого разрешения |
| CartoDB Dark Labels | Подписи городов и сёл |
